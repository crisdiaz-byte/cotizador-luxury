
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const parseFactoryData = async (text: string) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Analiza el siguiente texto que contiene datos de costos de fábrica de persianas y extrae una lista JSON estructurada. 
    Texto: "${text}"`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            descripcion: { type: Type.STRING },
            costoBase: { type: Type.NUMBER },
            medidas: { type: Type.STRING }
          },
          required: ["descripcion", "costoBase"]
        }
      }
    }
  });

  try {
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Error parsing Gemini response:", error);
    return [];
  }
};

export const generateQuotationSummary = async (quoteData: any) => {
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `Genera una breve recomendación de ventas profesional para este cliente basado en esta cotización: ${JSON.stringify(quoteData)}`,
  });
  return response.text;
};
